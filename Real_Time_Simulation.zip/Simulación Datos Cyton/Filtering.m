%%Filters
load 'chraw3'
fs_Hz = 250;
little_buff = zeros(1,10);
display_buff = zeros(1,5000);
cont = 1;

bpf = [5, 50];
[b,a] = butter(2,bpf/(fs_Hz / 2), 'bandpass');

notch = [59, 61];
[b2, a2] = butter(2,notch/(fs_Hz / 2), 'stop');

g = 1;
%% Graph
h = figure('Name','Sleep Simulator','NumberTitle','off','Color','w', 'Menu','none'); clf;
set(h, 'Position',  [300, 100, 800, 500])
hold on
grid on
xlim([2000 5000]);
ylim([-200 200]);
title('EEG Fpz-Cz','Color','k')
xlabel("Time (s)"+newline+"   ")
ylabel('Amplitude (uV)','Color','k')
x = linspace(1,5000,5000);

for i = 1:length(chraw3)
    little_buff(cont) = chraw3(i);
    
    if cont == 10
        cont = 1;
        display_buff = AppendandShift(display_buff,little_buff);
        display_buff_filt = filter(b2,a2,display_buff);
        display_buff_filt = filter(b,a,display_buff_filt);
        

        display = display_buff_filt;
        c = line(x,display(1,:),'Color','k');

        pause(0.01)
        g = ishandle(c);
        delete(c);
   
    else 
        cont = cont + 1;  
    end
    
    if ~g
        break
    end
end


