% -------------------------------------------------------------------------
% Autor: Jos� Pablo Mu�oz 
% Descripci�n: Funci�n para extraer caracter�sticas en tiempo real para la
% simulaci�n 
% -------------------------------------------------------------------------
function Input_Net = features_ext(Raw)
  L = 3000;
  feat = 21; 
  Input_Net = zeros(feat,1);
  cont = 0;
  
for c = 1:4
    if (c < 4)
        Input_Net(c+5*cont) = mean(abs(Raw(1:L/3,c)));
        Input_Net(2*c+4*cont) = mean(abs(Raw((L/3)+1:(2*L/3),c)));
        Input_Net(3*c+3*cont) = mean(abs(Raw((2*L/3)+1:L,c)));
        Input_Net(4*c+2*cont) = ZC_v2(Raw(1:L/3,c),0.01);
        Input_Net(5*c+cont) = ZC_v2(Raw((L/3)+1:(2*L/3),c),0.01);
        Input_Net(6*c) = ZC_v2(Raw((2*L/3)+1:L,c),0.01);
        cont = cont + 1;
    else
        Input_Net(19) = mean(abs(Raw(1:L/3,c)));
        Input_Net(20) = mean(abs(Raw((L/3)+1:(2*L/3),c)));
        Input_Net(21) = mean(abs(Raw((2*L/3)+1:L,c)));        
    end 
end
    